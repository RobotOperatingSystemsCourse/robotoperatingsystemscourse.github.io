#include <iostream>
#include <stack>
#include <string>

// Given a string s containing just the characters '(', ')', '{', '}', '['
// and ']', determine if the input string is valid.

// An input string is valid if:
//   * Open brackets must be closed by the same type of brackets.
//   * Open brackets must be closed in the correct order.
//   * Every close bracket has a corresponding open bracket of the same type.

// Examples:
// 1. Input: s = "()"
//    Output: true
// 2. Input: s = "()[]{}"
//    Output: true
// 3. Input: s = "(]"
//    Output: false
// 4. Input: s = "([)]"
//    Output: false

bool is_valid(std::string s) {
    // TODO: Implement the function
    return false;
}

int main() {
    std::string s = "()";
    std::cout << is_valid(s) << std::endl;
    s = "()[]{}";
    std::cout << is_valid(s) << std::endl;
    s = "(]";
    std::cout << is_valid(s) << std::endl;
    s = "([)]";
    std::cout << is_valid(s) << std::endl;
    s = "{[]}";
    std::cout << is_valid(s) << std::endl;
    return 0;
}