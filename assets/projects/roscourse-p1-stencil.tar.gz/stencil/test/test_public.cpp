#include <gtest/gtest.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <vector>
#include <thread>
#include <functional>
#include "util.h"
#include "robot/robot.h"

// Vector to store drive commands
std::vector<drive_cmd_t> drive_cmds;

// Mock function for drive
void drive(const drive_cmd_t* cmd) {
    drive_cmds.push_back(*cmd);
}

class UtilTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Code here will be called immediately after the constructor (right before each test).
        drive_cmds.clear();
    }

    void TearDown() override {
        // Code here will be called immediately after each test (right before the destructor).
    }
    
};

// Test signal_handler function with SIGINT
TEST_F(UtilTest, SignalHandlerSigint) {
    sigint_flag = 0;
    signal_handler(SIGINT);
    EXPECT_EQ(1, sigint_flag);
}

// Test signal_handler function with other signals
TEST_F(UtilTest, SignalHandlerOther) {
    sigint_flag = 0;
    signal_handler(SIGPIPE);
    signal_handler(SIGKILL);
    signal_handler(SIGTERM);
    signal_handler(SIGSTOP);
    EXPECT_EQ(0, sigint_flag);
}

// Test relay_drive_commands function
TEST_F(UtilTest, RelayDriveCommandsStop) {
    int pipefd[2];
    pipe(pipefd);
    int in_fd = pipefd[0];
    int out_fd = pipefd[1];

    drive_cmd_t cmd = {0, 1.0, 2.0, 3.0};
    write(out_fd, &cmd, sizeof(drive_cmd_t));
    close(out_fd);

    sigint_flag = 1; // To stop the loop
    relay_drive_commands(in_fd);

    // Check if the drive command was relayed correctly
    ASSERT_EQ(drive_cmds.size(), 1);
    EXPECT_EQ(drive_cmds[0].vx, 0.0);
    EXPECT_EQ(drive_cmds[0].vy, 0.0);
    EXPECT_EQ(drive_cmds[0].wz, 0.0);
}

// Test relay_drive_commands function
TEST_F(UtilTest, RelayDriveCommands) {
    sigint_flag = 0;

    int pipefd[2];
    pipe(pipefd);
    int in_fd = pipefd[0];
    int out_fd = pipefd[1];

    // Create a thread to call relay_drive_commands
    std::thread relay_thread(relay_drive_commands, in_fd);

    drive_cmd_t cmd = {0, 1.0, 2.0, 3.0};
    write(out_fd, &cmd, sizeof(drive_cmd_t));

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    cmd = {0, 2.0, 3.0, 4.0};
    write(out_fd, &cmd, sizeof(drive_cmd_t));
    close(out_fd);

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    // Send SIGINT signal
    sigint_flag = 1;

    // Join the thread
    relay_thread.join();

    // Check if the drive command was relayed correctly
    ASSERT_EQ(drive_cmds.size(), 3);
    EXPECT_EQ(drive_cmds[0].vx, 1.0);
    EXPECT_EQ(drive_cmds[0].vy, 2.0);
    EXPECT_EQ(drive_cmds[0].wz, 3.0);
    EXPECT_EQ(drive_cmds[1].vx, 2.0);
    EXPECT_EQ(drive_cmds[1].vy, 3.0);
    EXPECT_EQ(drive_cmds[1].wz, 4.0);
    EXPECT_EQ(drive_cmds[2].vx, 0.0);
    EXPECT_EQ(drive_cmds[2].vy, 0.0);
    EXPECT_EQ(drive_cmds[2].wz, 0.0);
}

// Test read_line function
TEST_F(UtilTest, ReadLine) {
    int pipefd[2];
    pipe(pipefd);
    int in_fd = pipefd[0];
    int out_fd = pipefd[1];

    const char* test_str = "test line\n";
    write(out_fd, test_str, strlen(test_str));
    close(out_fd);

    char buffer[256];
    ssize_t bytes_read = read_line(in_fd, buffer, sizeof(buffer));
    ASSERT_EQ(strlen(test_str), bytes_read);
    EXPECT_STREQ("test line", buffer);
}

// Test read_line function with small buffer
TEST_F(UtilTest, ReadLineSmallBuffer) {
    int pipefd[2];
    pipe(pipefd);
    int in_fd = pipefd[0];
    int out_fd = pipefd[1];

    const char* test_str = "this is a really long test line\n";
    write(out_fd, test_str, strlen(test_str));
    close(out_fd);

    char buffer[16];
    ssize_t bytes_read = read_line(in_fd, buffer, sizeof(buffer));
    ASSERT_EQ(sizeof(buffer) - 1, bytes_read);
    EXPECT_STREQ("this is a reall", buffer);
}

// Test read_line function with small buffer
TEST_F(UtilTest, ReadLineMultiLine) {
    int pipefd[2];
    pipe(pipefd);
    int in_fd = pipefd[0];
    int out_fd = pipefd[1];

    const char* test_str = "there are\n serveral\n lines\n in this test\n";
    write(out_fd, test_str, strlen(test_str));
    close(out_fd);

    char buffer[64];
    ssize_t bytes_read = read_line(in_fd, buffer, sizeof(buffer));
    ASSERT_EQ(10, bytes_read);
    EXPECT_STREQ("there are", buffer);
}

// Test parse_and_forward_commands function
TEST_F(UtilTest, ParseAndForwardCommandsStop) {
    int pipefda[2];
    pipe(pipefda);
    int in_fd_a = pipefda[0];
    int out_fd_a = pipefda[1];

    int pipefdb[2];
    pipe(pipefdb);
    int in_fd_b = pipefdb[0];
    int out_fd_b = pipefdb[1];

    const char* test_str = "cmd 1.0 2.0 3.0 1000\n";
    write(out_fd_a, test_str, strlen(test_str));
    close(out_fd_a);

    sigint_flag = 1; // To stop the loop
    parse_and_forward_commands(in_fd_a, out_fd_b);
    close(in_fd_a);
    close(out_fd_b);

    // Check if the drive command was parsed and forwarded correctly (because sigint is set, there should be no command)
    drive_cmd_t cmd;
    ssize_t bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    EXPECT_EQ(0, bytes_read);
    close(in_fd_b);
}

TEST_F(UtilTest, ParseAndForwardCommands) {
    int pipefda[2];
    pipe(pipefda);
    int in_fd_a = pipefda[0];
    int out_fd_a = pipefda[1];

    int pipefdb[2];
    pipe(pipefdb);
    int in_fd_b = pipefdb[0];
    int out_fd_b = pipefdb[1];

    const char* test_str = "cmd 1.0 2.0 3.0 100\n";
    write(out_fd_a, test_str, strlen(test_str));

    sigint_flag = 0;

    // Create a thread to call parse_and_forward_commands
    std::thread parse_thread(parse_and_forward_commands, in_fd_a, out_fd_b);

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(200));

    test_str = "cmd 2.0 3.0 4.0 100\n";
    write(out_fd_a, test_str, strlen(test_str));

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(200));

    test_str = "cmd 3.0 4.0 5.0 100\n";
    write(out_fd_a, test_str, strlen(test_str));
    close(out_fd_a);

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(200));

    // Send SIGINT signal
    sigint_flag = 1;

    // Join the thread
    parse_thread.join();
    close(in_fd_a);
    close(out_fd_b);

    // Check if the drive command was parsed and forwarded correctly
    drive_cmd_t cmd;
    ssize_t bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(1.0, cmd.vx);
    EXPECT_EQ(2.0, cmd.vy);
    EXPECT_EQ(3.0, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(2.0, cmd.vx);
    EXPECT_EQ(3.0, cmd.vy);
    EXPECT_EQ(4.0, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(3.0, cmd.vx);
    EXPECT_EQ(4.0, cmd.vy);
    EXPECT_EQ(5.0, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    close(in_fd_b);
    ASSERT_EQ(0, bytes_read);
}

// Test drive_square function
TEST_F(UtilTest, DriveSquareStop) {
    int pipefd[2];
    pipe(pipefd);
    int out_fd = pipefd[1];
    int in_fd = pipefd[0];

    sigint_flag = 1; // To stop the loop
    drive_square(out_fd);
    close(out_fd);

    drive_cmd_t cmd;
    ssize_t bytes_read = read(in_fd, &cmd, sizeof(drive_cmd_t));
    close(in_fd);
    ASSERT_EQ(0, bytes_read);
}

TEST_F(UtilTest, DriveSquare) {
    int pipefd[2];
    pipe(pipefd);
    int out_fd = pipefd[1];
    int in_fd = pipefd[0];

    sigint_flag = 0;

    // Create a thread to call drive_square
    std::thread drive_thread(drive_square, out_fd);

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(5000));

    // Send SIGINT signal
    sigint_flag = 1;

    // Join the thread
    drive_thread.join();
    close(out_fd);

    // Check if the drive commands were sent correctly
    drive_cmd_t cmd_1;
    ssize_t bytes_read = read(in_fd, &cmd_1, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);

    drive_cmd_t cmd_2;
    bytes_read = read(in_fd, &cmd_2, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);

    drive_cmd_t cmd_3;
    bytes_read = read(in_fd, &cmd_3, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);

    drive_cmd_t cmd_4;
    bytes_read = read(in_fd, &cmd_4, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);

    close(in_fd);

    EXPECT_EQ(0.0, cmd_1.vx + cmd_2.vx + cmd_3.vx + cmd_4.vx);
    EXPECT_EQ(0.0, cmd_1.vy + cmd_2.vy + cmd_3.vy + cmd_4.vy);
    EXPECT_EQ(0.0, cmd_1.wz + cmd_2.wz + cmd_3.wz + cmd_4.wz);
}

// Test convert_keys_to_drive_commands function
TEST_F(UtilTest, ConvertKeysToDriveCommandsStop) {
    int pipefda[2];
    pipe(pipefda);
    int in_fd_a = pipefda[0];
    int out_fd_a = pipefda[1];

    int pipefdb[2];
    pipe(pipefdb);
    int in_fd_b = pipefdb[0];
    int out_fd_b = pipefdb[1];

    const char* test_str = "w";
    write(out_fd_a, test_str, strlen(test_str));
    close(out_fd_a);

    sigint_flag = 1; // To stop the loop
    convert_keys_to_drive_commands(in_fd_a, out_fd_b);
    close(in_fd_a);
    close(out_fd_b);

    // Check if the drive command was converted and sent correctly (because sigint is set, there should be no command)
    drive_cmd_t cmd;
    ssize_t bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    close(in_fd_b);
    EXPECT_EQ(0, bytes_read);
}

// Test convert_keys_to_drive_commands function
TEST_F(UtilTest, ConvertKeysToDriveCommands) {
    int pipefda[2];
    pipe(pipefda);
    int in_fd_a = pipefda[0];
    int out_fd_a = pipefda[1];

    int pipefdb[2];
    pipe(pipefdb);
    int in_fd_b = pipefdb[0];
    int out_fd_b = pipefdb[1];

    const char* test_str = "w";
    write(out_fd_a, test_str, strlen(test_str));

    sigint_flag = 0;

    // Create a thread to call convert_keys_to_drive_commands
    std::thread convert_thread(convert_keys_to_drive_commands, in_fd_a, out_fd_b);

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    test_str = "a";
    write(out_fd_a, test_str, strlen(test_str));

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    test_str = "s";
    write(out_fd_a, test_str, strlen(test_str));

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    test_str = "d";
    write(out_fd_a, test_str, strlen(test_str));

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    test_str = "q";
    write(out_fd_a, test_str, strlen(test_str));

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    test_str = "e";
    write(out_fd_a, test_str, strlen(test_str));

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    test_str = " ";
    write(out_fd_a, test_str, strlen(test_str));
    close(out_fd_a);

    // Wait for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    // Send SIGINT signal
    sigint_flag = 1;

    // Join the thread
    convert_thread.join();
    close(in_fd_a);
    close(out_fd_b);

    // Check if the drive command was converted and sent correctly
    drive_cmd_t cmd;
    ssize_t bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(0.5, cmd.vx);
    EXPECT_EQ(0.0, cmd.vy);
    EXPECT_EQ(0.0, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(0.0, cmd.vx);
    EXPECT_EQ(0.5, cmd.vy);
    EXPECT_EQ(0.0, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(-0.5, cmd.vx);
    EXPECT_EQ(0.0, cmd.vy);
    EXPECT_EQ(0.0, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(0.0, cmd.vx);
    EXPECT_EQ(-0.5, cmd.vy);
    EXPECT_EQ(0.0, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(0.0, cmd.vx);
    EXPECT_EQ(0.0, cmd.vy);
    EXPECT_EQ(1.5, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(0.0, cmd.vx);
    EXPECT_EQ(0.0, cmd.vy);
    EXPECT_EQ(-1.5, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    ASSERT_EQ(sizeof(drive_cmd_t), bytes_read);
    EXPECT_EQ(0.0, cmd.vx);
    EXPECT_EQ(0.0, cmd.vy);
    EXPECT_EQ(0.0, cmd.wz);

    bytes_read = read(in_fd_b, &cmd, sizeof(drive_cmd_t));
    close(in_fd_b);
    EXPECT_EQ(0, bytes_read);
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}