#include "robot/robot.h"
#include "util.h"

int main() {
    // TODO: Set up signal handler for SIGINT

    int fd[2];
    // TODO: Create pipe

    pid_t pid;
    // TODO: Fork process

    if (pid == 0) {
        // Child process

        // TODO: Close unused end of pipe

        // TODO: Initialize the robot

        // TODO: Relay drive commands from the pipe to the robot

        // TODO: Deinitialize the robot

        // TODO: Close file descriptor for the used end of the pipe
    } else {
        // Parent process

        // TODO: Close unused end of pipe

        // TODO: Send drive commands to the pipe

        // TODO: Close file descriptor for the used end of the pipe
    }

    return 0;
}
