#include "robot/robot.h"
#include "util.h"

int main() {
    // TODO: Set up signal handler for SIGINT

    // TODO: Parse commands from STDIN and forward them to STDOUT

    return 0;
}
