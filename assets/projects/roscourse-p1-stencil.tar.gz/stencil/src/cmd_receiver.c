#include "robot/robot.h"
#include "util.h"

int main(int argc, char** argv) {
    // TODO: Set up signal handler for SIGINT

    // TODO: Initialize the robot

    // TODO: Relay drive commands from STDIN to the robot

    // TODO: Deinitialize the robot

    return 0;
}
