#include <gtest/gtest.h>
#include "sockets/client.hpp"
#include "sockets/server.hpp"

class ClientTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Code here will be called immediately after the constructor (right before each test).
    }

    void TearDown() override {
        // Code here will be called immediately after each test (right before the destructor).
    }

    Client client;
};

class ServerTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Setup code if needed
    }

    void TearDown() override {
        // Cleanup code if needed
    }
};

class ConnectionTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Setup code if needed
    }

    void TearDown() override {
        // Cleanup code if needed
    }
};

TEST_F(ClientTest, DefaultConstructor) {
    EXPECT_FALSE(client.is_connected());
    EXPECT_FALSE(client.is_opened());
}

TEST_F(ClientTest, ConstructorWithURI) {
    URI uri("127.0.0.1", 8080);
    Client client_with_uri(uri);
    EXPECT_FALSE(client_with_uri.is_connected());
    EXPECT_TRUE(client_with_uri.is_opened());
}

TEST_F(ClientTest, Open) {
    URI uri("127.0.0.1", 8080);
    EXPECT_EQ(client.open(uri), 0);
    EXPECT_TRUE(client.is_opened());
}

TEST_F(ClientTest, OpenAlreadyOpened) {
    URI uri("127.0.0.1", 8080);
    client.open(uri);
    EXPECT_EQ(client.open(uri), 0);
}

TEST_F(ClientTest, SendNotConnected) {
    const char* message = "Hello, World!";
    size_t size = strlen(message);
    EXPECT_EQ(client.send(message, size), -1);
}

TEST_F(ClientTest, RecvNotConnected) {
    char buffer[1024];
    size_t size = sizeof(buffer);
    EXPECT_EQ(client.recv(buffer, size), -1);
}

TEST_F(ClientTest, Close) {
    URI uri("127.0.0.1", 8080);
    client.open(uri);
    client.connect();
    client.close();
    EXPECT_FALSE(client.is_connected());
    EXPECT_FALSE(client.is_opened());
}

TEST_F(ClientTest, GetServerURINotConnected) {
    EXPECT_EQ(client.get_server_uri(), URI());
}

TEST_F(ServerTest, DefaultConstructor) {
    Server server;
    EXPECT_FALSE(server.is_opened());
    EXPECT_FALSE(server.is_bound());
    EXPECT_FALSE(server.is_listening());
}

TEST_F(ServerTest, ConstructorWithURI) {
    URI uri("127.0.0.1", 8080);
    Server server(uri);
    EXPECT_TRUE(server.is_opened());
}

TEST_F(ServerTest, Open) {
    Server server;
    URI uri("127.0.0.1", 8080);
    EXPECT_EQ(server.open(uri), 0);
    EXPECT_TRUE(server.is_opened());
}

TEST_F(ServerTest, Bind) {
    Server server;
    URI uri("127.0.0.1", 8080);
    server.open(uri);
    EXPECT_EQ(server.bind(), 0);
    EXPECT_TRUE(server.is_bound());
}

TEST_F(ServerTest, Listen) {
    Server server;
    URI uri("127.0.0.1", 8080);
    server.open(uri);
    server.bind();
    EXPECT_EQ(server.listen(), 0);
    EXPECT_TRUE(server.is_listening());
}

TEST_F(ServerTest, Accept) {
    Server server;
    URI uri("127.0.0.1", 8080);
    server.open(uri);
    server.bind();
    server.listen();
    Connection* connection = nullptr;
    EXPECT_EQ(server.accept(&connection), 1); // Assuming no client is connecting
    delete connection;
}

TEST_F(ServerTest, GetURI) {
    Server server;
    URI uri("127.0.0.1", 8080);
    server.open(uri);
    server.bind();
    EXPECT_EQ(server.get_uri(), uri);
}

TEST_F(ConnectionTest, Send) {
    Connection connection;
    const char* message = "Hello";
    size_t size = strlen(message);
    EXPECT_EQ(connection.send(message, size), -1); // Connection not opened
}

TEST_F(ConnectionTest, Recv) {
    Connection connection;
    char buffer[1024];
    size_t size = sizeof(buffer);
    EXPECT_EQ(connection.recv(buffer, size), -1); // Connection not opened
}

TEST_F(ConnectionTest, Close) {
    Connection connection;
    connection.close();
    EXPECT_FALSE(connection.is_opened());
}

TEST_F(ConnectionTest, GetClientURI) {
    Connection connection;
    EXPECT_EQ(connection.get_client_uri(), URI()); // Connection not opened
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}