import struct

class Pose2D:
    def __init__(self, utime, x, y, theta):
        self.utime = utime
        self.x = x
        self.y = y
        self.theta = theta
    
    def __str__(self):
        return f"utime: {self.utime}, x: {self.x}, y: {self.y}, theta: {self.theta}"
    
    def __repr__(self):
        return str(self)
    
    def to_bytes(self):
        data = struct.pack("q", self.utime)
        data += struct.pack("fff", self.x, self.y, self.theta)
        return data
    
    @staticmethod
    def from_bytes(data):
        utime = struct.unpack("q", data[:8])[0]
        x, y, theta = struct.unpack("fff", data[8:20])
        return Pose2D(utime, x, y, theta)
    
    @staticmethod
    def size():
        return 20