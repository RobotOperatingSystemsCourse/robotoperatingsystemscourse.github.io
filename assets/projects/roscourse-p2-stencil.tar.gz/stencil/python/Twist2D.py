import struct

class Twist2D:
    def __init__(self, utime, vx, vy, wz):
        self.utime = utime
        self.vx = vx
        self.vy = vy
        self.wz = wz
    
    def __str__(self):
        return f"utime: {self.utime}, vx: {self.vx}, vy: {self.vy}, wz: {self.wz}"
    
    def __repr__(self):
        return str(self)
    
    def to_bytes(self):
        data = struct.pack("q", self.utime)
        data += struct.pack("fff", self.vx, self.vy, self.wz)
        return data
    
    @staticmethod
    def from_bytes(data):
        utime = struct.unpack("q", data[:8])[0]
        vx, vy, wz = struct.unpack("fff", data[8:20])
        return Twist2D(utime, vx, vy, wz)
    
    @staticmethod
    def size():
        return 20