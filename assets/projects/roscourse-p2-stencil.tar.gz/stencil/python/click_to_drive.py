import socket
import numpy as np
import threading
import signal
import pygame
from argparse import ArgumentParser
import logging
import errno

from LidarScan import LidarScan
from Pose2D import Pose2D
from Twist2D import Twist2D

ctrl_c_pressed = False
mbot_mutex = threading.Lock()
current_pose = None
current_pose_mutex = threading.Lock()
current_scan = None
current_scan_mutex = threading.Lock()

mbot_img = pygame.transform.scale(pygame.image.load("mbot-omni.png"), (50, 50))
pgon = None
pose_trail = []

logging.basicConfig(level=logging.INFO, format='[%(asctime)s] [%(levelname)s] [%(message)s]')

def signal_handler(sig, frame):
    global ctrl_c_pressed
    logging.info("Ctrl+C pressed")
    ctrl_c_pressed = True

def update_plot(screen):
    global current_scan, current_scan_mutex, current_pose, current_pose_mutex, mbot_img, pgon

    if not current_scan or not current_pose:
        return

    screen.fill((255, 255, 255))  # Clear screen with white

    # Filter ranges > 0
    with current_scan_mutex:
        valid_indices = np.intersect1d(np.where(np.array(current_scan.ranges) > 0), np.where(np.array(current_scan.intensities) > 0))
        valid_ranges = np.array(current_scan.ranges)[valid_indices]
        valid_thetas = np.array(current_scan.thetas)[valid_indices]

    center_x, center_y, robot_theta = 512, 512, 0
    with current_pose_mutex:
        if current_pose is not None:
            center_x = 512 + int(current_pose.x * 100)
            center_y = 512 - int(current_pose.y * 100)
            robot_theta = current_pose.theta

    edge_points = []
    for theta, r in zip(valid_thetas, valid_ranges):
        end_x = int(center_x + r * 100 * np.cos(theta))
        end_y = int(center_y - r * 100 * np.sin(theta))
        edge_points.append((end_x, end_y))

    # Draw the outline connecting the outer edge of the rays
    if edge_points:
        pgon = pygame.draw.polygon(screen, (255, 201, 11), edge_points)
        pygame.draw.polygon(screen, (0, 35, 76), edge_points, 3)

    # Add current pose to the plot as label
    with current_pose_mutex:
        if current_pose is not None:
            monospace_font_name = pygame.font.match_font('couriernew', 'consolas', 'dejavusansmono')
            font = pygame.font.Font(monospace_font_name, 18)
            font.bold = True
            pose_text = f"x: {current_pose.x}\ny: {current_pose.y}\nθ: {current_pose.theta}"
            lines = pose_text.split('\n')
            y_offset = 25  # Place text below the bounding box
            pygame.draw.rect(screen, (255, 255, 255), (10, 10, 300, 100))
            pygame.draw.rect(screen, (0, 0, 0), (10, 10, 300, 100), 2)
            for line in lines:
                text_surface = font.render(line, True, (0, 0, 0))
                screen.blit(text_surface, (25, y_offset))
                y_offset += text_surface.get_height()

            pose_trail.append((center_x, center_y))
            if len(pose_trail) > 1000:
                pose_trail.pop(0)
            
            if len(pose_trail) > 1:
                pygame.draw.lines(screen, (154, 51, 36), False, pose_trail, 4)

    # Plot the robot (mbot-omni.png)
    mbot_img_transformed = pygame.transform.rotate(mbot_img, np.degrees(robot_theta))
    robot_rect = mbot_img_transformed.get_rect(center=(center_x, center_y))
    screen.blit(mbot_img_transformed, robot_rect)

    pygame.display.flip()

def mbot_thread(mbot_client):
    global ctrl_c_pressed, current_pose
    while not ctrl_c_pressed:
        bytes_received = 0
        pose_bytes = b""
        try:
            with mbot_mutex:
                while bytes_received < Pose2D.size() and not ctrl_c_pressed:
                    data = mbot_client.recv(Pose2D.size() - bytes_received)
                    bytes_received += len(data)
                    pose_bytes += data

            if ctrl_c_pressed:
                break
            
            new_pose = Pose2D.from_bytes(pose_bytes)
            with current_pose_mutex:
                current_pose = new_pose

        except Exception as e:
            if e.errno == errno.EWOULDBLOCK:
                continue
            logging.error(f"Error receiving data from mbot_client: {e}")
            break

    logging.info("MBot thread exiting")

def lidar_thread(lidar_client):
    global ctrl_c_pressed, current_scan, current_scan_mutex
    while not ctrl_c_pressed:
        bytes_received = 0
        scan_bytes = b""
        try:
            while bytes_received < LidarScan.size() and not ctrl_c_pressed:
                data = lidar_client.recv(LidarScan.size() - bytes_received)
                bytes_received += len(data)
                scan_bytes += data

            if ctrl_c_pressed:
                break

            new_scan = LidarScan.from_bytes(scan_bytes)
            with current_scan_mutex:
                current_scan = new_scan
        
        except Exception as e:
            if e.errno == errno.EWOULDBLOCK:
                continue
            logging.error(f"Error receiving data from lidar_client: {e}")
            break

    logging.info("Lidar thread exiting")

def main():
    global ctrl_c_pressed, pgon, current_pose, current_pose_mutex, current_scan, current_scan_mutex

    parser = ArgumentParser()
    parser.add_argument("address", type=str)
    args = parser.parse_args()

    # Register the signal handler
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Create a socket object
    lidar_client = socket.socket()
    mbot_client = socket.socket()

    # connect to the server on local computer
    address = args.address
    lidar_port = 8100
    mbot_port = 8200

    logging.info(f"Connecting to Lidar server at {address}:{lidar_port}")
    try:
        lidar_client.connect((address, lidar_port))
    except socket.timeout:
        logging.error("Timeout occurred while connecting to Lidar server")
        return
    except Exception as e:
        logging.error(f"Error connecting to Lidar server: {e}")
        return
    logging.info("Connected to Lidar server")

    logging.info(f"Connecting to MBot server at {address}:{mbot_port}")
    try:
        mbot_client.connect((address, mbot_port))
    except socket.timeout:
        logging.error("Timeout occurred while connecting to MBot server")
        return
    except Exception as e:
        logging.error(f"Error connecting to MBot server: {e}")
        return
    logging.info("Connected to MBot server")

    lidar_client.setblocking(False)  # Set non-blocking mode
    mbot_client.setblocking(False)  # Set non-blocking mode

    # Initialize pygame
    pygame.init()
    screen = pygame.display.set_mode((1024, 1024))
    pygame.display.set_caption('Click to Drive')

    # Create the MBot thread
    mbot_thread_handle = threading.Thread(target=mbot_thread, args=(mbot_client,), daemon=True)
    mbot_thread_handle.start()

    # Create the Lidar thread
    lidar_thread_handle = threading.Thread(target=lidar_thread, args=(lidar_client,), daemon=True)
    lidar_thread_handle.start()

    # Plot lidar scan in main process (pygame is not thread safe)
    while not ctrl_c_pressed:
        for event in pygame.event.get():
            # Handle quit event
            if event.type == pygame.QUIT:
                ctrl_c_pressed = True
            # Handle mouse click event
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos

                # Check if the click is inside the polygon (inside the lidar scan)
                if pgon:
                   r,g,b,_ = tuple(screen.get_at((mouse_x, mouse_y)))
                   if r != 255 or g != 201 or b != 11:
                       continue

                # Convert to world coordinates in meters
                with current_pose_mutex:
                    x = (mouse_x - 512) / 100
                    y = -(mouse_y - 512) / 100

                # Send the drive command
                pose = Pose2D(0, x, y, 0)
                with mbot_mutex:
                    logging.info(f"Sending pose command: {pose}")
                    mbot_client.send(pose.to_bytes())

        update_plot(screen)

    if mbot_thread_handle.is_alive():
        logging.info("Waiting for MBot thread to join")
        mbot_thread_handle.join()
    if lidar_thread_handle.is_alive():
        logging.info("Waiting for Lidar thread to join")
        lidar_thread_handle.join()

    # Close the socket
    lidar_client.close()
    mbot_client.close()

    # Quit pygame
    pygame.quit()

if __name__ == "__main__":
    main()