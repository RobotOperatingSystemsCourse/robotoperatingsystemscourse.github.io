import struct

MAX_SCANS = 1024

class LidarScan:
    def __init__(self, utime, ranges, thetas, intensities, times):
        self.utime = utime
        self.ranges = ranges
        self.thetas = thetas
        self.intensities = intensities
        self.times = times

    def __str__(self):
        return f"utime: {self.utime}, ranges: {self.ranges}, thetas: {self.thetas}, intensities: {self.intensities}, times: {self.times}"

    def __repr__(self):
        return str(self)

    def to_bytes(self):
        data = struct.pack("q", self.utime)
        data += struct.pack(f"{MAX_SCANS}f", *self.ranges)
        data += struct.pack(f"{MAX_SCANS}f", *self.thetas)
        data += struct.pack(f"{MAX_SCANS}f", *self.intensities)
        data += struct.pack(f"{MAX_SCANS}f", *self.times)
        return data

    @staticmethod
    def from_bytes(data):
        utime = struct.unpack("q", data[:8])[0]
        ranges = struct.unpack(f"{MAX_SCANS}f", data[8:8 + 4 * MAX_SCANS])
        thetas = struct.unpack(f"{MAX_SCANS}f", data[8 + 4 * MAX_SCANS:8 + 8 * MAX_SCANS])
        intensities = struct.unpack(f"{MAX_SCANS}f", data[8 + 8 * MAX_SCANS:8 + 12 * MAX_SCANS])
        times = struct.unpack(f"{MAX_SCANS}f", data[8 + 12 * MAX_SCANS:8 + 16 * MAX_SCANS])
        return LidarScan(utime, ranges, thetas, intensities, times)
    
    @staticmethod
    def size():
        return 8 + 16 * MAX_SCANS