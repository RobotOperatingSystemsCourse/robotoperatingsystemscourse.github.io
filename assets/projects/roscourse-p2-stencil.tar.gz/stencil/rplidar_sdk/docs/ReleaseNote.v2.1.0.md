RPLIDAR Public SDK v2.1.0 Release Note
======================================
- [new feature] Re-implemented the data retrieving logic based on async fetching and decoding mechanism to improve performance
- [new feature] RPLIDAR C1 support
- [improvement] 