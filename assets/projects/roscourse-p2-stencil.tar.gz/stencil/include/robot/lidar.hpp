#include <inttypes.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

#include <cstddef>
#include <cstring>
#include <functional>
#include <iostream>
#include <thread>

#include <rplidar.h>

#include "robot/common.hpp"

#define LIDAR_SCAN_SIZE 8192
#define MAX_SCANS 1024

using namespace rp::standalone::rplidar;

#pragma pack(push, 1)
struct LidarScan {
    int64_t utime;
    int32_t num_ranges;
    float ranges[MAX_SCANS];
    float thetas[MAX_SCANS];
    float intensities[MAX_SCANS];
    float times[MAX_SCANS];

    const uint8_t* encode() const;
    static const LidarScan* decode(const uint8_t* msg, size_t size);
};
#pragma pack(pop)

class Lidar {
  public:
    Lidar(const std::string &port, uint32_t baudrate, uint16_t pwm);
    ~Lidar();

    void set_on_scan(std::function<void(Lidar &, const LidarScan &)> on_scan);
    int connect();
    int check_health();
    int start(bool block = true);
    void stop();

  private:
    std::thread run_thread;
    std::string port;
    RPlidarDriver *drv;
    LidarScan current_scan;
    std::function<void(Lidar &, const LidarScan &)> on_scan;
    uint32_t baudrate;
    uint16_t pwm;
    bool is_connected;
    bool stop_flag;

    void run();
};
