#pragma once

#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/time.h>

int64_t utime_now();