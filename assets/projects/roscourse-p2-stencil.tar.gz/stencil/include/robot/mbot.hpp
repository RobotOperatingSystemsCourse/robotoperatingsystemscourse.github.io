#pragma once

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>

#include <cmath>
#include <cstring>
#include <functional>
#include <iostream>
#include <mutex>
#include <semaphore>
#include <string>
#include <thread>

#include "robot/common.hpp"

/**
 * @brief Message structure for time synchronization
 */
#pragma pack(push, 1)
struct Timestamp {
    int64_t utime;

    const uint8_t* encode() const;
    static Timestamp* decode(uint8_t* msg, size_t size);
};
#pragma pack(pop)

/**
 * @brief Drive command structure
 */
#pragma pack(push, 1)
struct Twist2D {
    int64_t utime;
    float vx;
    float vy;
    float wz;

    const uint8_t* encode() const;
    static Twist2D* decode(uint8_t* msg, size_t size);
};
#pragma pack(pop)

/**
 * @brief Pose structure
 */
#pragma pack(push, 1)
struct Pose2D {
    int64_t utime;
    float x;
    float y;
    float theta;

    const uint8_t* encode() const;
    static Pose2D* decode(uint8_t* msg, size_t size);
};
#pragma pack(pop)

class MBot {
  public:
    MBot(const std::string &port);
    ~MBot();

    void set_on_pose(std::function<void(MBot &, const Pose2D &)> on_pose);
    void start(bool block = true);
    void stop();
    void drive(float vx, float vy, float wz);
    void drive_to(float x, float y, float theta);
    void abort();
    void reset_pose();

  private:
    std::thread timesync_thread;
    std::thread listener_thread;
    std::thread controller_thread;

    std::string port;
    struct termios options;

    std::mutex robot_fd_mutex;
    std::mutex current_pose_mutex;
    std::mutex goal_pose_mutex;
    std::mutex controller_running_mutex;
    std::binary_semaphore controller_start_semaphore;
    std::binary_semaphore controller_abort_semaphore;

    int robot_fd;
    std::function<void(MBot &, const Pose2D &)> on_pose;

    Pose2D current_pose;
    Pose2D goal_pose;

    bool stop_flag;
    bool controller_running;

    void timesync();
    void listener();
    void controller();

    void handle_msg(uint16_t topic_id, void *msg, size_t msg_len);

    uint8_t checksum(uint8_t *addends, int len);
    int encode_msg(uint8_t *msg, int msg_len, uint16_t topic, uint8_t *rospkt, int rospkt_len);

    bool read_header(uint8_t *header_data);
    bool validate_header(uint8_t *header_data);
    bool read_message(uint8_t *msg, uint16_t msg_len, char *topic_msg_data_checksum);
    bool validate_message(uint8_t *header_data, uint8_t *msg, uint16_t msg_len, char topic_msg_data_checksum);
};
