#pragma once

#include <arpa/inet.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>

#include <iostream>
#include <random>
#include <set>
#include <string>

struct URI {
    std::string ip;
    int port;

    URI();
    URI(const std::string &ip, int port);
    URI(const URI &uri);
    URI &operator=(const URI &uri);
    ~URI();

    bool operator<(const URI &other) const;
    bool operator==(const URI &other) const;
    bool operator!=(const URI &other) const;

    std::string to_string() const;

    friend std::ostream &operator<<(std::ostream &os, const URI &uri) {
        os << uri.to_string();
        return os;
    }
};