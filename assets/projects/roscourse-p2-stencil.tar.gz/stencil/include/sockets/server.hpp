#pragma once

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <iostream>
#include <string>

#include "sockets/uri.hpp"

class Server;

class Connection {
    friend class Server;

  public:
    Connection();
    Connection(const Connection& other) = delete;
    ~Connection();

    int send(const void* const message, size_t& size);
    int recv(void* message, size_t& size);
    void close();

    bool is_opened() { return opened; }
    URI get_client_uri();

  private:
    URI client_uri;
    sockaddr_in client;
    int fd;
    bool opened;

    Connection(int fd, sockaddr_in client);
};

class Server {
  public:

    Server();
    Server(const Server& other) = delete;
    Server(const URI& uri);
    ~Server();

    int open(const URI& uri);
    int bind();
    int listen();
    int accept(Connection **connection);
    void close();

    bool is_opened() { return opened; }
    bool is_bound() { return bound; }
    bool is_listening() { return listening; }
    URI get_uri();

  private:
    URI uri;
    sockaddr_in server;
    int fd;
    bool opened;
    bool bound;
    bool listening;
};