#pragma once

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <poll.h>

#include <iostream>
#include <string>

#include "sockets/uri.hpp"

class Client {
  public:
    Client();
    Client(const Client& other) = delete;
    Client(const URI& uri);
    ~Client();

    int open(const URI& uri);
    int connect();
    int send(const void* const message, size_t& size);
    int recv(void* message, size_t& size);
    void close();

    bool is_opened();
    bool is_writable();
    bool is_readable();
    URI get_server_uri();

  private:
    URI server_uri;
    sockaddr_in server;
    int fd;
    bool connected;
    bool opened;
};