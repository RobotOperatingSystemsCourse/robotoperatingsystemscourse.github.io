#include <functional>
#include <iostream>
#include <mutex>
#include <string>

#include "robot/common.hpp"
#include "robot/mbot.hpp"
#include "sockets/server.hpp"

Connection *connection = nullptr;
std::mutex connection_mtx;
bool ctrl_c_pressed = false;

void on_pose(MBot &mbot, const Pose2D &pose) {
    // TODO: Send the pose to the client if the connection is open. If the send
    //       fails, stop the MBot and close the connection. This function will
    //       be called from a separate thread by the MBot driver when a new pose
    //       is available.
    //       Make sure to lock the connection_mtx mutex before accessing, 
    //       modifying, or using the connection and unlock it after!
}

void signal_handler(int signum) {
    // TODO: Handle the SIGINT and SIGTERM signals. Set the ctrl_c_pressed flag.
    //       For all other signals, ignore them.
}

int main() {
    // TODO: Set the handler for the necessary signals (SIGINT, SIGTERM,
    //       and SIGPIPE)

    // TODO: Create the MBot driver on port "/dev/mbot_lcm"

    // TODO: Set the on pose callback

    // TODO: Create a server that will listen on all available interfaces
    //       using port 8200

    // TODO: Bind the server to the address and port. If the bind fails, 
    //       return -1

    // TODO: Listen for incoming connections. If the listen fails, return -1.

    // TODO: Implement the main loop of the driver.
    //       If a connection is not open, accept incoming connections. Once a 
    //       connection is accepted, start the MBot, send a drive command of 0, 
    //       and reset the pose. 
    //       If a connection is open, receive a Pose2D message from the client 
    //       and drive the robot to the specified pose.
    //       Do this until SIGINT or SIGTERM is received.
    //       Make sure to lock the connection_mtx mutex before accessing, 
    //       modifying, or using the connection and unlock it after!

    return 0;
}