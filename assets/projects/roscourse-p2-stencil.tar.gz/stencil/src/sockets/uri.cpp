#include "sockets/uri.hpp"

URI::URI() : ip(""), port(0) {}

URI::URI(const std::string &_ip, int _port) : ip(_ip), port(_port) {}

URI::URI(const URI &uri) : ip(uri.ip), port(uri.port) {}

URI &URI::operator=(const URI &uri) {
    if (this == &uri) {
        return *this;
    }

    ip = uri.ip;
    port = uri.port;
    return *this;
}

URI::~URI() {}

bool URI::operator<(const URI &other) const { return ip < other.ip || (ip == other.ip && port < other.port); }

bool URI::operator==(const URI &other) const { return ip == other.ip && port == other.port; }

bool URI::operator!=(const URI &other) const { return !(*this == other); }

std::string URI::to_string() const { return ip + ":" + std::to_string(port); }
