#include "sockets/client.hpp"

Client::Client() {
    // TODO: Initialize the client object with the connected and opened flags
    //       set to false
}

Client::Client(const URI& uri) { 
    // TODO: Initialize the client object with the connected and opened flags
    //       set to false. Open the client socket with the given URI
}

Client::~Client() { 
    // TODO: Close the client socket
}

int Client::open(const URI& uri) {
    // TODO: If the server is already opened return 0

    // TODO: Initialize the sockaddr_in server structure with the URI 
    //       information using the IPv4 protocol. Use htons() to convert the
    //       port number from host byte order to network byte order. Use
    //       inet_aton() to convert the address from the IPv4
    //       numbers-and-dots notation into binary form in network byte
    //       order
    
    // TODO: Create a socket using the IPv4 protocol and the TCP protocol. If
    //       the socket creation fails, return -1

    // TODO: Set the SO_REUSEADDR socket option to allow the socket to be
    //       reused. If the setsockopt call fails, close the socket and return
    //       -1

    // TODO: Make the socket non-blocking. First, get the socket flags using 
    //       fcntl with F_GETFL. Then, update the flags with a bitwise-OR with 
    //       O_NONBLOCK using fcntl with F_SETFL. If the fcntl call fails, 
    //       close the socket and return -1

    // TODO: Set the opened flag to true and return 0

    return -1;
}

int Client::connect() {
    // TODO: If the client is already connected, return 0

    // TODO: Connect to the server using the socket file descriptor and the
    //       sockaddr_in server structure. If the connection fails, close the
    //       socket and return -1. (Hint: use errno to check if the connection
    //       would block)

    // TODO: Set the server URI from the server information received from the
    //       connect call. Use inet_ntoa() to convert the address from binary
    //       form to the IPv4 numbers-and-dots notation and ntohs() to convert
    //       the port number from network byte order to host byte order.
    
    // TODO: Set the connected flag to true and return 0

    return -1;
}

int Client::send(const void* const message, size_t& size) {
    // TODO: If the client is not connected, return -1

    // TODO: Send the message to the server using the socket file descriptor. 
    //       If the send call fails, close the socket and return -1. If the 
    //       send call would block, return 1. Otherwise, return 0. Make sure 
    //       to update the size parameter to the number of bytes sent. 

    return -1;
}

int Client::recv(void* message, size_t& size) {
    // TODO: If the client is not connected, return -1

    // TODO: Receive a message from the server using the socket file descriptor. 
    //       If the recv call fails, close the socket and return -1. If the 
    //       recv call would block, return 1. Otherwise, return 0. Make sure 
    //       to update the size parameter to the number of bytes received.

    return -1;
}

void Client::close() {
    // TODO: Close the socket file descriptor and set the connected and opened
    //       flag to false
}


bool Client::is_opened() {
    // TODO: If the opened flag is false, return false
    
    // TODO: Poll the socket file descriptor to check if the socket is still
    //       valid. If the poll call fails, return false. Otherwise, use the
    //       bits in the revents field of the pollfd structure to return whether
    //       the socket is still valid.
    //       Hint: Use the POLLNVAL bit to check if the socket is invalid
    //       Hint: Use the poll call with a timeout of 0 to check if the socket
    //             is still valid

    return false;
}

bool Client::is_writable() {
    // TODO: If the connected flag is false, return false

    // TODO: Poll the socket file descriptor to check if the socket is writable.
    //       If the poll call fails, return false. Otherwise, use the bits in
    //       the revents field of the pollfd structure to return whether the
    //       socket is writable.
    //       Hint: Use the POLLOUT bit to check if the socket is invalid
    //       Hint: Use the poll call with a timeout of 0 to check if the socket
    //             is still valid
    
    return false;
}

bool Client::is_readable() {
    // TODO: If the connected flag is false, return false

    // TODO: Poll the socket file descriptor to check if the socket is readable.
    //       If the poll call fails, return false. Otherwise, use the bits in
    //       the revents field of the pollfd structure to return whether the
    //       socket is readable.
    //       Hint: Use the POLLIN bit to check if the socket is invalid
    //       Hint: Use the poll call with a timeout of 0 to check if the socket
    //             is still valid

    return false;
}


URI Client::get_server_uri() {
    // TODO: If the client is not connected, return an empty URI
    //       Otherwise, return the server URI

    return URI();
}