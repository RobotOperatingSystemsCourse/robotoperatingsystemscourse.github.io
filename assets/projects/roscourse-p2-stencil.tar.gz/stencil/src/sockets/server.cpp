#include "sockets/server.hpp"

Server::Server() {
    // TODO: Initialize the server object with the opened, bound, and listening
    //       flags set to false
}

Server::Server(const URI& uri) : Server() {
    // TODO: Initialize the server object with the opened, bound, and listening
    //       flags set to false. Open the server socket with the given URI.
}

Server::~Server() {
    // TODO: Close the server socket
}

int Server::open(const URI& uri) {
    // TODO: If the server is already opened return 0.

    // TODO: Initialize the sockaddr_in server structure with the URI 
    //       information using the IPv4 protocol. Use htons() to convert the
    //       port number from host byte order to network byte order. Use
    //       inet_aton() to convert the address from the IPv4
    //       numbers-and-dots notation into binary form in network byte
    //       order
    
    // TODO: Create a socket using the IPv4 protocol and the TCP protocol. If
    //       the socket creation fails, return -1

    // TODO: Set the SO_REUSEADDR socket option to allow the socket to be
    //       reused. If the setsockopt call fails, close the socket and return
    //       -1

    // TODO: Make the socket non-blocking. First, get the socket flags using 
    //       fcntl with F_GETFL. Then, update the flags with a bitwise-OR with 
    //       O_NONBLOCK using fcntl with F_SETFL. If the fcntl call fails, 
    //       close the socket and return -1

    // TODO: Set the opened flag to true and return 0

    return -1;
}

int Server::bind() {
    // TODO: If the server is not opened, return -1. If the server is already
    //       bound, return 0

    // TODO: Bind the server to the address and port specified in the 
    //       sockaddr_in server structure. If the bind call fails, close the 
    //       socket and return -1

    // TODO: Update the sockaddr_in server structure using getsockname. If this
    //       call fails, close the socket and return -1

    // TODO: Set the server URI from the server information received from the
    //       getsockname call. Use inet_ntoa() to convert the address from binary
    //       form to the IPv4 numbers-and-dots notation and ntohs() to convert
    //       the port number from network byte order to host byte order. Set
    //       the connected flag to true and return 0

    // TODO: Set the bound flag to true and return 0
    
    return -1;
}

int Server::listen() {
    // TODO: If the server is not bound, return -1. If the server is
    //       already listening, return 0

    // TODO: Listen for incoming connections on the server. If the listen call
    //       fails, close the socket and return -1.

    // TODO: Set the listening flag to true and return 0

    return -1;
}

int Server::accept(Connection **connection) {
    // TODO: If the server is not listening, return -1

    // TODO: Create a sockaddr_in client structure to store the client 
    //       information into and accept a connection. If the accept call fails,
    //       return -1. If the call would block, return 1.

    // TODO: Make the accepted socket non-blocking. First, get the socket flags
    //       using fcntl with F_GETFL. Then, update the flags with a bitwise-OR
    //       with O_NONBLOCK using fcntl with F_SETFL. If the fcntl call fails, 
    //       close the socket and return -1

    // TODO: Allocate a new Connection object at the connection pointer using 
    //       the Connection private constructor. If the allocation fails, close
    //       the socket and return -1. Otherwise, return 0.

    return -1;
}

void Server::close() {
    // TODO: Close the server socket and set the opened, bound, and listening
    //       flags to false
}

URI Server::get_uri() {
    // TODO: If the server is not bound, return an empty URI. Otherwise, return
    //       the URI of the server

    return URI();
}

Connection::Connection() {
    // TODO: Initialize the Connection object with the file descriptor set to -1
    //       and the opened flag set to false
}

Connection::Connection(int fd, sockaddr_in client) {
    // TODO: Initialize the Connection object with the given file descriptor and
    //       client information. Set the opened flag to true and initialize the
    //       client URI using the sockaddr_in client structure.
}

Connection::~Connection() {
    // TODO: Close the connection
}

int Connection::send(const void* const message, size_t& size) {
    // TODO: If the connection is not opened, return -1

    // TODO: Send the message to the client using the socket file descriptor. 
    //       If the send call fails, close the socket and return -1. If the 
    //       send call would block, return 1. Otherwise, return 0. Make sure 
    //       to update the size parameter to the number of bytes sent.

    return -1;
}

int Connection::recv(void* message, size_t& size) {
    // TODO: If the connection is not opened, return -1

    // TODO: Receive a message from the client using the socket file descriptor. 
    //       If the recv call fails, close the socket and return -1. If the 
    //       recv call would block, return 1. Otherwise, return 0. Make sure 
    //       to update the size parameter to the number of bytes received.

    return -1;
}

void Connection::close() {
    // TODO: Close the socket file descriptor and set the opened flag to false
}

URI Connection::get_client_uri() {
    // TODO: If the connection is not opened, return an empty URI
    //       Otherwise, return the URI of the client.

    return URI();
}