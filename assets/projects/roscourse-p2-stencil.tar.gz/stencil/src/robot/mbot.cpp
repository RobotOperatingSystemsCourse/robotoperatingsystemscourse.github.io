#include "robot/mbot.hpp"

#define SYNC_FLAG 0xff                                         /**< Sync flag for ROS packets */
#define VERSION_FLAG 0xfe                                      /**< Version flag for ROS packets */
#define ROS_HEADER_LENGTH 7                                    /**< Length of the ROS packet header */
#define ROS_FOOTER_LENGTH 1                                    /**< Length of the ROS packet footer */
#define ROS_PKG_LENGTH (ROS_HEADER_LENGTH + ROS_FOOTER_LENGTH) /**< Length of the ROS packet overhead */

#define MBOT_VEL_CMD 214        /**< Topic ID for velocity commands */
#define MBOT_TIMESYNC 201       /**< Topic ID for time synchronization */
#define MBOT_ODOMETRY 210       /**< Topic ID for odometry */
#define MBOT_ODOMETRY_RESET 211 /**< Topic ID for odometry reset */

const uint8_t* Timestamp::encode() const {
    // TODO: Encode this structure into a byte array

    return nullptr;
}

Timestamp* Timestamp::decode(uint8_t* msg, size_t size) {
    // TODO: Decode the byte array into a Timestamp structure. Return nullptr if
    //       the size is incorrect.
    
    return nullptr;
}

const uint8_t* Twist2D::encode() const {
    // TODO: Encode this structure into a byte array
    
    return nullptr;
}

Twist2D* Twist2D::decode(uint8_t* msg, size_t size) {
    // TODO: Decode the byte array into a Twist2D structure. Return nullptr if
    //       the size is incorrect.
    
    return nullptr;
}

const uint8_t* Pose2D::encode() const {
    // TODO: Encode this structure into a byte array
    
    return nullptr;
}

Pose2D* Pose2D::decode(uint8_t* msg, size_t size) {
    // TODO: Decode the byte array into a Pose2D structure. Return nullptr if
    //       the size is incorrect.
    
    return nullptr;
}

MBot::MBot(const std::string &port)
    : robot_fd(-1),
      port(port),
      stop_flag(false),
      controller_running(false),
      controller_start_semaphore(0),
      controller_abort_semaphore(0) {
    robot_fd = open(this->port.c_str(), O_RDWR);
    if (robot_fd < 0) {
        std::cerr << "Error, cannot open the serial port." << std::endl;
        exit(-1);
    }

    // Set up the serial port
    tcgetattr(robot_fd, &options);
    cfsetspeed(&options, B115200);
    options.c_cflag &= ~(CSIZE | PARENB | CSTOPB | CRTSCTS);
    options.c_cflag |= CS8 | CREAD | CLOCAL;
    options.c_oflag &= ~OPOST;
    options.c_lflag &= ~(ICANON | ISIG | ECHO | IEXTEN); /* Set non-canonical mode */
    options.c_cc[VTIME] = 1;
    options.c_cc[VMIN] = 0;
    cfmakeraw(&options);
    tcflush(robot_fd, TCIFLUSH);
    tcsetattr(robot_fd, TCSANOW, &options);
    if (tcgetattr(robot_fd, &options) != 0) {
        close(robot_fd);
        exit(-1);
    }
}

MBot::~MBot() {
    stop();
    close(robot_fd);
}

void MBot::set_on_pose(std::function<void(MBot &, const Pose2D &)> on_pose) { this->on_pose = on_pose; }

void MBot::start(bool block) {
    stop(); // Ensure all threads have been joined
    stop_flag = false;

    // Start timesync thread
    timesync_thread = std::thread(&MBot::timesync, this);

    // Start listener thread
    listener_thread = std::thread(&MBot::listener, this);

    // Start controller thread
    controller_thread = std::thread(&MBot::controller, this);

    if (block) {
        timesync_thread.join();
        listener_thread.join();
        controller_thread.join();
    }
}

void MBot::stop() {
    stop_flag = true;
    if (timesync_thread.get_id() != std::this_thread::get_id() && timesync_thread.joinable()) {
        timesync_thread.join();
    }
    if (listener_thread.get_id() != std::this_thread::get_id() && listener_thread.joinable()) {
        listener_thread.join();
    }
    if (controller_thread.get_id() != std::this_thread::get_id() && controller_thread.joinable()) {
        controller_thread.join();
    }
}

void MBot::drive(float vx, float vy, float wz) {
    // Create Twist2D message
    Twist2D cmd;
    cmd.utime = utime_now();
    cmd.vx = vx;
    cmd.vy = vy;
    cmd.wz = wz;

    // Encode the command
    uint8_t msg[sizeof(Twist2D) + ROS_PKG_LENGTH];
    encode_msg((uint8_t *)&cmd, sizeof(Twist2D), MBOT_VEL_CMD, msg, sizeof(msg));

    // Send the drive command
    robot_fd_mutex.lock();
    write(robot_fd, msg, sizeof(msg));
    robot_fd_mutex.unlock();
}

void MBot::drive_to(float x, float y, float theta) {
    goal_pose_mutex.lock();
    goal_pose.x = x;
    goal_pose.y = y;
    goal_pose.theta = theta;
    goal_pose_mutex.unlock();
    controller_start_semaphore.release();
    std::cout << "Set goal: x: " << x << ", y: " << y << ", theta: " << theta << std::endl;
}

void MBot::abort() {
    controller_running_mutex.lock();
    if (controller_running) {
        controller_abort_semaphore.release();
    }
    controller_running_mutex.unlock();
}

void MBot::reset_pose() {
    Pose2D msg;
    msg.utime = utime_now();
    msg.x = 0;
    msg.y = 0;
    msg.theta = 0;
    const size_t msg_size = sizeof(Pose2D) + ROS_PKG_LENGTH;
    uint8_t rospkt[msg_size];
    if (encode_msg((uint8_t *)&msg, sizeof(Pose2D), MBOT_ODOMETRY_RESET, rospkt, msg_size) < 0) {
        perror("encode_msg");
    }

    int status;
    robot_fd_mutex.lock();
    status = write(robot_fd, rospkt, msg_size);
    robot_fd_mutex.unlock();
    if (status < 0) {
        perror("write");
    }
}

void MBot::timesync() {
    while (!stop_flag) {
        // Encode the timesync message
        Timestamp msg;
        msg.utime = utime_now();
        const size_t msg_size = sizeof(Timestamp) + ROS_PKG_LENGTH;
        uint8_t rospkt[msg_size];
        if (encode_msg((uint8_t *)&msg, sizeof(Timestamp), MBOT_TIMESYNC, rospkt, msg_size) < 0) {
            perror("encode_msg");
            break;
        }

        // Send the timesync message
        robot_fd_mutex.lock();
        int status = write(robot_fd, rospkt, msg_size);
        robot_fd_mutex.unlock();
        if (status < 0) {
            perror("write");
            break;
        }

        // Run at 2 Hz
        usleep(500000);
    }
}

void MBot::listener() {
    uint8_t header_data[ROS_HEADER_LENGTH];
    header_data[0] = 0x00;

    while (!stop_flag) {
        // Read the header and check if we lost serial connection
        robot_fd_mutex.lock();
        int header_status = read_header(header_data);
        robot_fd_mutex.unlock();
        if (header_status < 0) {
            std::cerr << "[ERROR] Serial device is not available" << std::endl;
            break;
        }

        bool valid_header = (header_status == 1);
        if (valid_header) {
            valid_header = validate_header(header_data);
        }

        if (valid_header) {
            uint16_t msg_len = ((uint16_t)header_data[3] << 8) + (uint16_t)header_data[2];
            uint16_t topic_id = ((uint16_t)header_data[6] << 8) + (uint16_t)header_data[5];
            uint8_t *msg = new uint8_t[msg_len];

            int avail = 0;
            ioctl(robot_fd, FIONREAD, &avail);
            while (avail < (msg_len + 1) && !stop_flag) {
                usleep(1000);
                ioctl(robot_fd, FIONREAD, &avail);
            }
            if (stop_flag) {
                break;
            }

            // Read the message and check if we lost serial connection
            char topic_msg_data_checksum = 0;
            robot_fd_mutex.lock();
            int message_status = read_message(msg, msg_len, &topic_msg_data_checksum);
            robot_fd_mutex.unlock();
            if (message_status < 0) {
                std::cerr << "[ERROR] Serial device is not available" << std::endl;
                break;
            }

            bool valid_message = (message_status == 1);
            if (valid_message) {
                valid_message = validate_message(header_data, msg, msg_len, topic_msg_data_checksum);
                if (valid_message) {
                    handle_msg(topic_id, msg, msg_len);
                }
            }
            delete[] msg;
        }

        header_data[0] = 0x00;
    }
}

void MBot::controller() {
    const float kp_v = 0.6;
    const float kp_t = 1.2;
    while (!stop_flag) {
        if (!controller_start_semaphore.try_acquire()) {
            usleep(1000);
            continue;
        }

        controller_running_mutex.lock();
        controller_running = true;
        controller_running_mutex.unlock();

        while (!stop_flag) {
            if (controller_abort_semaphore.try_acquire()) {
                break;
            }

            current_pose_mutex.lock();
            Pose2D current = current_pose;
            current_pose_mutex.unlock();

            Pose2D goal;
            goal_pose_mutex.lock();
            goal = goal_pose;
            goal_pose_mutex.unlock();

            float dx = goal.x - current.x;
            float dy = goal.y - current.y;
            float dt = goal.theta - current.theta;

            float mag = sqrt(dx * dx + dy * dy);
            bool reached_linear_goal = mag < 0.01;
            bool reached_angular_goal = fabs(dt) < M_PI / 360;

            float robot_vx = kp_v * dx;
            float robot_vy = kp_v * dy;
            float global_vx = cos(current.theta) * robot_vx + sin(current.theta) * robot_vy;
            float global_vy = -sin(current.theta) * robot_vx + cos(current.theta) * robot_vy;
            float wz = kp_t * dt;

            if (reached_linear_goal && reached_angular_goal) {
                drive(0, 0, 0);
                break;
            } else if (reached_linear_goal) {
                global_vx = 0.0;
                global_vy = 0.0;
            } else if (reached_angular_goal) {
                wz = 0.0;
            }

            drive(global_vx, global_vy, wz);
            usleep(10000);
        }

        controller_running_mutex.lock();
        controller_running = false;
        controller_running_mutex.unlock();
    }
}

void MBot::handle_msg(uint16_t topic_id, void *msg, size_t msg_len) {
    switch (topic_id) {
        case MBOT_ODOMETRY:
            if (msg_len != sizeof(Pose2D)) {
                std::cerr << "Received message with invalid size for MBOT_ODOMETRY" << std::endl;
                break;
            }
            current_pose_mutex.lock();
            std::memcpy(&current_pose, msg, sizeof(Pose2D));
            current_pose_mutex.unlock();
            on_pose(*this, current_pose);
            break;
        default:
            break;
    }
}

uint8_t MBot::checksum(uint8_t *addends, int len) {
    // takes in an array and sums the contents then checksums the array
    int sum = 0;
    for (int i = 0; i < len; i++) {
        sum += addends[i];
    }
    return 255 - ((sum) % 256);
}

int MBot::encode_msg(uint8_t *msg, int msg_len, uint16_t topic, uint8_t *rospkt, int rospkt_len) {
    // SANITY CHECKS
    if (msg_len + ROS_PKG_LENGTH != rospkt_len) {
        return -1;
    }

    // CREATE ROS PACKET
    // for ROS protocol and packet format see link: http://wiki.ros.org/rosserial/Overview/Protocol
    rospkt[0] = SYNC_FLAG;
    rospkt[1] = VERSION_FLAG;
    rospkt[2] = (uint8_t)(msg_len & 0xFF);  // message length lower 8/16b via bitwise AND and cast
    rospkt[3] = (uint8_t)(msg_len >> 8);    // message length higher 8/16b via bitshift and cast

    uint8_t cs1_addends[2] = {rospkt[2], rospkt[3]};
    rospkt[4] = checksum(cs1_addends, 2);  // checksum over message length
    rospkt[5] = (uint8_t)(topic & 0xFF);   // message topic lower 8/16b via bitwise AND and cast
    rospkt[6] = (uint8_t)(topic >> 8);     // message length higher 8/16b via bitshift and cast

    memcpy(&rospkt[ROS_HEADER_LENGTH], msg, msg_len);  // copy message data to packet

    uint8_t cs2_addends[msg_len + 2];  // create array for the checksum over topic and message content
    cs2_addends[0] = rospkt[5];
    cs2_addends[1] = rospkt[6];
    for (int i = 0; i < msg_len; i++) {
        cs2_addends[i + 2] = msg[i];
    }

    rospkt[rospkt_len - 1] = checksum(cs2_addends, msg_len + 2);  // checksum over message data and topic

    return 0;
}

bool MBot::read_header(uint8_t *header_data) {
    unsigned char trigger_val = 0x00;
    int rc = 0x00;
    while (trigger_val != 0xff && !stop_flag && rc != 1) {
        rc = read(robot_fd, &trigger_val, 1);
        if (rc < 0) {
            return -1;
        }
    }
    header_data[0] = trigger_val;

    rc = read(robot_fd, &header_data[1], ROS_HEADER_LENGTH - 1);
    if (rc < 0) {
        return -1;
    }

    return (rc == ROS_HEADER_LENGTH - 1);
}

// Header validation function
bool MBot::validate_header(uint8_t *header_data) {
    bool valid_header = (header_data[1] == 0xfe);
    uint8_t cs1_addends[2] = {header_data[2], header_data[3]};
    uint8_t cs_msg_len = checksum(cs1_addends, 2);
    valid_header = valid_header && (cs_msg_len == header_data[4]);

    return valid_header;
}

// Message read function
bool MBot::read_message(uint8_t *msg, uint16_t msg_len, char *topic_msg_data_checksum) {
    int rc = read(robot_fd, msg, msg_len);
    if (rc < 0) {
        return -1;
    }
    bool valid_message = (rc == msg_len);

    rc = read(robot_fd, topic_msg_data_checksum, 1);
    if (rc < 0) {
        return -1;
    }
    valid_message = valid_message && (rc == 1);

    return valid_message;
}

// Message validation function
bool MBot::validate_message(uint8_t *header_data, uint8_t *msg, uint16_t msg_len, char topic_msg_data_checksum) {
    uint8_t cs2_addends[msg_len + 2];
    cs2_addends[0] = header_data[5];
    cs2_addends[1] = header_data[6];
    for (int i = 0; i < msg_len; i++) {
        cs2_addends[i + 2] = msg[i];
    }

    uint8_t cs_topic_msg_data = checksum(cs2_addends, msg_len + 2);
    bool valid_message = (cs_topic_msg_data == topic_msg_data_checksum);

    return valid_message;
}
