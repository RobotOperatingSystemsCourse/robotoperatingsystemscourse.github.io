#include <iostream>
#include <string>

#include "sockets/client.hpp"

int main() {
    // TODO: Write a program that creates a client, connects to a server running
    //       on the same machine at port 7800, sends a message "Hello, server!",
    //       receives a message from the server, and prints the received
    //       message. The program should handle any errors that occur during 
    //       the process.
}