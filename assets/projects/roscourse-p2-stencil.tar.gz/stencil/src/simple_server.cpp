#include <iostream>
#include <string>

#include "sockets/server.hpp"

int main() {
    // TODO: Write a program that hosts a server on all interfaces at port 7800.
    //       This server  should accept a connection from a client, receive a 
    //       message from the client, print the received message, and send
    //       "Hello, client!" to the client.
    //       If any of the steps fail, the program should return 1.
    //       The server should continue to accept connections until a SIGINT or SIGTERM
    //       signal is received.
}