#include <functional>
#include <iostream>
#include <mutex>
#include <string>

#include "robot/common.hpp"
#include "robot/lidar.hpp"
#include "sockets/server.hpp"

Connection *connection = nullptr;
std::mutex connection_mtx;
bool ctrl_c_pressed = false;

void on_scan(Lidar &lidar, const LidarScan &scan) {
    // TODO: Send the scan to the client if the connection is open. If the send
    //       fails, stop the LiDAR and close the connection. This function will 
    //       be called from a separate thread by the LiDAR driver when a new 
    //       scan is available.
    //       Make sure to lock the connection_mtx mutex before accessing, 
    //       modifying, or using the connection and unlock it after!
}

void signal_handler(int signum) {
    // TODO: Handle the SIGINT and SIGTERM signals. Set the ctrl_c_pressed flag.
    //       For all other signals, ignore them.
}

int main() {
    // TODO: Set the handler for the necessary signals (SIGINT, SIGTERM, 
    //       and SIGPIPE)

    // TODO: Create the LiDAR driver with port "/dev/rplidar", baudrate 115200, 
    //       and PWM 700

    // TODO: Connect to the LiDAR. If the connection fails, return -1.

    // TODO: Check the health status of the LiDAR. If the health status is not
    //       good, return -1.

    // TODO: Set the LiDAR scan callback function

    // TODO: Create a server that will listen on all available interfaces 
    //       using port 8100

    // TODO: Bind the server to the address and port. If the bind fails, return -1.

    // TODO: Listen for incoming connections. If the listen fails, return -1.

    // TODO: Implement the main loop of the driver.
    //       If a connection is not open, accept incoming connections. Once a 
    //       connection is accepted, start the LiDAR.
    //       Do this until SIGINT or SIGTERM is received.
    //       Make sure to lock the connection_mtx mutex before accessing, 
    //       modifying, or using the connection and unlock it after!

    return 0;
}
